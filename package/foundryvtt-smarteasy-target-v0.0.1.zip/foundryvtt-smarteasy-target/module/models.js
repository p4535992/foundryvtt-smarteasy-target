class SmartTargetModel {
    constructor(index, color, image) {
        // Declare your class properties
        this.index = 0;
        this.color = '#ff9829';
        this.image = '';
        this.index = index;
        this.color = color;
        this.image = image;
    }
}
